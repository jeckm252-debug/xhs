# XHS Liquid Glass Redesign

一个尽量少依赖小红书私有类的 Theos tweak 原型。

## 功能

- 透明/磨砂液态玻璃悬浮底栏
- 首页 / 消息 / 我 三个导航按钮
- 中间红色发布按钮
- 当前 Tab 红色高亮
- 圆角、边框、高光、阴影
- 点击 Tab 使用系统触感反馈
- 尽量只依赖 UIKit / QuartzCore
- 只注入 `com.xingin.xiaohongshu`

## 编译

```bash
make package
```

GitHub Actions 会自动执行编译并把 `.dylib` 与 `.deb` 放到 Artifacts。

## 注意

这个版本刻意不依赖小红书内部私有类名，因此不保证所有版本的小红书都能自动识别真实的底栏结构。
如果当前版本的小红书不是标准 `UITabBarController`，需要再针对该版本的界面层级做适配。

## 注入

`XHSLiquidGlass.plist` 已经限制 Bundle 为：

`com.xingin.xiaohongshu`

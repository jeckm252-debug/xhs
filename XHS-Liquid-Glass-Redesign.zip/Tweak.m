#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

#pragma mark - XHS Liquid Glass
// Generic, low-dependency UI tweak.
// It intentionally avoids private XHS classes so the project is easier to rebuild
// when the app updates. The tab controller is used only as a navigation bridge.

static char kLGInstalledKey;
static char kLGOriginalTabBarHiddenKey;

static UIColor *LGRed(void) {
    return [UIColor colorWithRed:1.0 green:0.145 blue:0.26 alpha:1.0];
}

static void LGSwizzle(Class cls, SEL original, SEL replacement) {
    Method a = class_getInstanceMethod(cls, original);
    Method b = class_getInstanceMethod(cls, replacement);
    if (!a || !b) return;
    method_exchangeImplementations(a, b);
}

@interface LGLiquidBar : UIVisualEffectView
@property(nonatomic, weak) UITabBarController *tabController;
@property(nonatomic, strong) NSArray<NSString *> *titles;
@property(nonatomic, strong) NSArray<NSString *> *symbols;
@property(nonatomic, strong) NSMutableArray<UIButton *> *tabButtons;
@property(nonatomic, strong) UIButton *publishButton;
- (void)syncSelection;
@end

@implementation LGLiquidBar

- (instancetype)initWithFrame:(CGRect)frame {
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark];
    self = [super initWithEffect:blur];
    if (!self) return nil;

    self.layer.cornerRadius = 28.0;
    self.layer.cornerCurve = kCACornerCurveContinuous;
    self.layer.borderWidth = 0.7;
    self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.22].CGColor;
    self.clipsToBounds = NO;

    _titles = @[@"首页", @"消息", @"我"];
    _symbols = @[@"house.fill", @"message.fill", @"person.fill"];
    _tabButtons = [NSMutableArray array];

    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    CGFloat publish = 58.0;
    CGFloat side = 8.0;
    CGFloat usable = w - publish - 18.0;
    CGFloat cell = usable / 3.0;

    for (NSInteger i = 0; i < self.tabButtons.count; i++) {
        UIButton *b = self.tabButtons[i];
        b.frame = CGRectMake(side + i * cell, 5, cell - 3, h - 10);
    }

    self.publishButton.frame = CGRectMake(w - publish - 7, 5, publish, h - 10);
    self.publishButton.layer.cornerRadius = (h - 10) / 2.0;
}

- (void)buildButtons {
    for (UIView *v in self.subviews.copy) {
        if ([v isKindOfClass:UIButton.class]) [v removeFromSuperview];
    }
    [self.tabButtons removeAllObjects];

    for (NSInteger i = 0; i < self.titles.count; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.tag = 100 + i;
        button.tintColor = [UIColor whiteColor];
        button.titleLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
        button.layer.cornerRadius = 22;
        button.layer.cornerCurve = kCACornerCurveContinuous;

        if (@available(iOS 13.0, *)) {
            UIImageSymbolConfiguration *cfg =
                [UIImageSymbolConfiguration configurationWithPointSize:17 weight:UIImageSymbolWeightMedium];
            UIImage *image = [UIImage systemImageNamed:self.symbols[i] withConfiguration:cfg];
            [button setImage:image forState:UIControlStateNormal];
            button.imageView.contentMode = UIViewContentModeScaleAspectFit;
        }

        [button setTitle:self.titles[i] forState:UIControlStateNormal];
        button.imageEdgeInsets = UIEdgeInsetsMake(-8, 0, 0, 0);
        button.titleEdgeInsets = UIEdgeInsetsMake(25, -20, 0, 0);
        [button addTarget:self action:@selector(tabTapped:) forControlEvents:UIControlEventTouchUpInside];

        [self addSubview:button];
        [self.tabButtons addObject:button];
    }

    UIButton *p = [UIButton buttonWithType:UIButtonTypeSystem];
    p.tintColor = UIColor.whiteColor;
    p.backgroundColor = LGRed();
    p.layer.shadowColor = LGRed().CGColor;
    p.layer.shadowOpacity = 0.30;
    p.layer.shadowRadius = 10;
    p.layer.shadowOffset = CGSizeMake(0, 4);

    if (@available(iOS 13.0, *)) {
        UIImageSymbolConfiguration *cfg =
            [UIImageSymbolConfiguration configurationWithPointSize:22 weight:UIImageSymbolWeightBold];
        [p setImage:[UIImage systemImageNamed:@"plus" withConfiguration:cfg] forState:UIControlStateNormal];
    }

    [p addTarget:self action:@selector(publishTapped:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:p];
    self.publishButton = p;
    [self syncSelection];
}

- (void)tabTapped:(UIButton *)sender {
    NSInteger index = sender.tag - 100;
    if (self.tabController && index < self.tabController.viewControllers.count) {
        self.tabController.selectedIndex = index;
        [UIImpactFeedbackGenerator new].impactOccurred;
        [self syncSelection];
    }
}

- (void)publishTapped:(UIButton *)sender {
    UIImpactFeedbackGenerator *g = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
    [g impactOccurred];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"XHSLGPublishTapped" object:self];
}

- (void)syncSelection {
    NSInteger selected = self.tabController.selectedIndex;
    for (NSInteger i = 0; i < self.tabButtons.count; i++) {
        UIButton *b = self.tabButtons[i];
        BOOL on = (i == selected);
        b.backgroundColor = on ? [LGRed() colorWithAlphaComponent:0.18] : UIColor.clearColor;
        b.tintColor = on ? LGRed() : [UIColor colorWithWhite:1 alpha:0.90];
        [b setTitleColor:(on ? LGRed() : [UIColor colorWithWhite:1 alpha:0.90]) forState:UIControlStateNormal];
    }
}

@end

@interface UITabBarController (XHSLG)
- (void)xhlg_viewDidAppear:(BOOL)animated;
- (void)xhlg_viewDidLayoutSubviews;
@end

static LGLiquidBar *LGBarForController(UITabBarController *tc) {
    return objc_getAssociatedObject(tc, &kLGInstalledKey);
}

static void LGInstallForController(UITabBarController *tc) {
    if (!tc.view.window) return;
    if (LGBarForController(tc)) {
        [LGBarForController(tc) syncSelection];
        return;
    }

    // Only install when there is a conventional tab-controller structure.
    if (tc.viewControllers.count < 3) return;

    UITabBar *native = tc.tabBar;
    if (!native || native.bounds.size.height < 1) return;

    CGRect converted = [native convertRect:native.bounds toView:tc.view];
    CGFloat width = MIN(tc.view.bounds.size.width - 28.0, 430.0);
    CGFloat x = (tc.view.bounds.size.width - width) / 2.0;
    CGFloat bottom = MAX(10.0, tc.view.safeAreaInsets.bottom + 6.0);
    CGFloat h = 64.0;

    LGLiquidBar *bar = [[LGLiquidBar alloc] initWithFrame:CGRectMake(x, tc.view.bounds.size.height - bottom - h, width, h)];
    bar.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    bar.tabController = tc;
    [bar buildButtons];

    [tc.view addSubview:bar];
    [tc.view bringSubviewToFront:bar];

    native.hidden = YES;
    objc_setAssociatedObject(tc, &kLGInstalledKey, bar, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(tc, &kLGOriginalTabBarHiddenKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@implementation UITabBarController (XHSLG)

- (void)xhlg_viewDidAppear:(BOOL)animated {
    [self xhlg_viewDidAppear:animated];
    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.xingin.xiaohongshu"]) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        LGInstallForController(self);
    });
}

- (void)xhlg_viewDidLayoutSubviews {
    [self xhlg_viewDidLayoutSubviews];

    if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.xingin.xiaohongshu"]) return;

    LGLiquidBar *bar = LGBarForController(self);
    if (!bar) return;

    CGFloat width = MIN(self.view.bounds.size.width - 28.0, 430.0);
    CGFloat x = (self.view.bounds.size.width - width) / 2.0;
    CGFloat bottom = MAX(10.0, self.view.safeAreaInsets.bottom + 6.0);
    bar.frame = CGRectMake(x, self.view.bounds.size.height - bottom - 64.0, width, 64.0);
    [self.view bringSubviewToFront:bar];
    [bar syncSelection];
}

@end

__attribute__((constructor))
static void XHSLGInit(void) {
    @autoreleasepool {
        if (![[NSBundle mainBundle].bundleIdentifier isEqualToString:@"com.xingin.xiaohongshu"]) return;

        dispatch_async(dispatch_get_main_queue(), ^{
            LGSwizzle(UITabBarController.class,
                      @selector(viewDidAppear:),
                      @selector(xhlg_viewDidAppear:));
            LGSwizzle(UITabBarController.class,
                      @selector(viewDidLayoutSubviews),
                      @selector(xhlg_viewDidLayoutSubviews));
        });
    }
}
